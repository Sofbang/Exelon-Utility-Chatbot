export declare function wordsToNumbers(text: string, options?: { fuzzy: boolean }): string | number | null;
export default wordsToNumbers;
