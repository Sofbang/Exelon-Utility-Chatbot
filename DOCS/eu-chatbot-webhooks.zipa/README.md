
*********-Steps to Deploy app in ACCS-********

1. Run following Curl Commands
	- curl -i -X PUT -u tulacenath@gmail.com:Nm0f6lgy https://sofbangmobile.storage.oraclecloud.com/v1/Storage-sofbangmobile/eu-chatbot-webhooks
	- curl -i -X PUT -u tulacenath@gmail.com:Nm0f6lgy https://sofbangmobile.storage.oraclecloud.com/v1/Storage-sofbangmobile/eu-chatbot-webhooks/node-eu-chatbot-webhooks.zip -T D:\Projects\EXELON\ExelonUtilityChatbot\eu-chatbot-webhooks\node-eu-chatbot-webhooks.zip

2. 